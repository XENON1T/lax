===============================
Lichens for Analyzing XENON1T
===============================


.. image:: https://img.shields.io/pypi/v/lax.svg
        :target: https://pypi.python.org/pypi/lax

.. image:: https://img.shields.io/travis/tunnell/lax.svg
        :target: https://travis-ci.org/tunnell/lax

.. image:: https://readthedocs.org/projects/lax/badge/?version=latest
        :target: https://lax.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/tunnell/lax/shield.svg
     :target: https://pyup.io/repos/github/tunnell/lax/
     :alt: Updates

.. image:: https://api.codacy.com/project/badge/Grade/724ba633bd6b4079b977e0aa623b327d
     :target: https://www.codacy.com/app/tunnell/lax?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=XENON1T/lax&amp;utm_campaign=Badge_Grade
     :alt: Style

Package for standardizing event selections on hax minitrees.


* Free software: GNU General Public License v3
* Documentation: https://lax.readthedocs.io.


Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

