"""Module defining key components to lax"""

__version__ = '0.11.1'

from . import lichens
