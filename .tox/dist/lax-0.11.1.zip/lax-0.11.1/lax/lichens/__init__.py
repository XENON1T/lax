"""Module containing all lichen definitions"""
from . import sciencerun0
