=====
Usage
=====

To use Lichens for Analyzing XENON1T in a project::

    import lax
