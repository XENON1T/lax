Welcome to Lichens for Analyzing XENON1T's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage
   contributing
   authorshistory

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
